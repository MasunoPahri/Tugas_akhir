@extends('content.admin.admin_base')

@section('subtitle') Beranda @stop
@section('pageTitle') Beranda @stop

@section('content')
    <h1 id="wlmsg">You're Logged-In to Admin Panel!!</h1>
@stop