<div class="row">
    <div class="col-md-8">
        <h1>Dasbor {{ $sess }} </h1>
    </div>
</div>
<br>
<div class="content">
    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#pending" aria-controls="pending" 
                role="tab" data-toggle="tab">Proyek Pending
            </a>
        </li>
        <li role="presentation">
            <a href="#ongoing" aria-controls="ongoing" 
                role="tab" data-toggle="tab">Proyek Berjalan
            </a>
        </li>
        <li role="presentation">
            <a href="#finish" aria-controls="finish" 
                role="tab" data-toggle="tab">Proyek Selesai
            </a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="pending">
            <br>
            <div class="row">
                @foreach($projects as $project)
                    @if($project->status != "ongoing" && $project->status != "finished")
                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="{{ asset('/images/img1.png') }}" alt="...">
                                <div class="caption">
                                    <h3>
                                        <a href="/WEB/view-detail/pending/{{ $project->id_proyek }}">
                                            {{ $project->nama_proyek }}
                                        </a>
                                    </h3>
                                    <p>{{ $project->status }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="ongoing">
            <br>
            <div class="row">
                @foreach($projects as $project)
                    @if($project->status == "ongoing")
                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="{{ asset('/images/img1.png') }}" alt="...">
                                <div class="caption">
                                    <h3>
                                        <a href="/WEB/view-detail/ongoing/{{ $project->id_proyek }}">
                                            {{ $project->nama_proyek }}
                                        </a>
                                    </h3>
                                    <p>{{ $project->status }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="finish">
            <br>
            <div class="row">
                @foreach($projects as $project)
                    @if($project->status == "finished")
                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="{{ asset('/images/img1.png') }}" alt="...">
                                <div class="caption">
                                    <h3>
                                        <a href="/WEB/view-detail/finish/{{ $project->id_proyek }}">
                                            {{ $project->nama_proyek }}
                                        </a>
                                    </h3>
                                    <p>{{ $project->status }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</div>