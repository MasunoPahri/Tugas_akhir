<div class="row hd">
    <div class="col-md-8">
        <h2>Buat Proyek Baru</h2>
        <p>Info Dasar</p>
    </div>
</div>
<br>
<div class="form">
    <form action="/WEB/project/sizing" method="post" class="form-horizontal">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <div class="form-group">
            <label class="col-md-2 ">Judul Proyek</label>
            <div class="col-md-6">
                <input type="text" class="form-control" name="title" required
                    placeholder="contoh: Kemeja Batik Perusahaan PT. XYZ">
            </div>
        </div>
        
        <div class="form-group">
            <label class="col-md-2 ">Pilih Metode Pengukuran</label>
            <div class="col-md-6">
                <div class="radio">
                    <span><label><input type="radio" name="sizingType" required value="customize">Ukuran Sendiri</label></span>
                    <span><label><input type="radio" name="sizingType" required value="standart">Ukuran Standart</label></span>
                </div>
            </div>
        </div>
        
        <div class="col-md-offset-6">
            <div class="col-md-4">
                <button class="btn btn-info btn-block">Selanjutnya</button>
            </div>
        </div>
    </form>
</div>