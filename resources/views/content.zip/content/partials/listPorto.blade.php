@section('subtitle') Daftar Portofolio @stop
<div class="row">
    <div class="col-md-8">
        <h1>Porotofolio Anda </h1>
    </div>
</div>
<br>
<div class="content">
    <br>
    <div class="row">
        <div class="col-sm-6 col-md-4">
            <div class="thumbnail">
                <img src="{{ asset('/images/img1.png') }}" alt="...">
                <div class="caption">
                    <h3>Judul Portofolio</h3>
                    <p>...</p>
                    <p>
                        <a href="/WEB/detailPorto/" class="btn btn-info" role="button">Lihat Detail</a> 
                        <a href="/WEBs/dltPorto/" 
                            class="btn btn-danger" role="button">Hapus</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>