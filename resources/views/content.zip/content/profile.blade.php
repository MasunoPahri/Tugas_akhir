@extends('base')

@section('subtitle') Lihat Profil @stop

@section('content')
<div class="col-md-12 profile-wrapper">
    <div class="col-md-3 leftside">
        <div class="upper">
            <div class="img-profile">
                <img src="{{ asset('/images/img1.png') }}" alt="">
            </div>
            @if(@mode == "myProfile")
            <div class="ctaBtn-profile">
                <a href="#" class="btn btn-default btn-block">Edit Profile</a>
                <a href="#" class="btn btn-default btn-block">Ubah Password</a>
            </div>
            @endif
        </div>
        <div class="bottom">
            <p><b>Daftar Skill</b></p>
            <ul>
                @foreach($userDetail->skills as $skill)
                    <li style="text-transform: capitalize;">{{ $skill->nama_skill }}</li>
                @endforeach
            </ul>
        </div>
    </div>
    <div class="col-md-1"></div>
    <div class="col-md-8 rightside">
        <div class="row upper">
            @if($userDetail->peran == "Penjahit" || $userDetail->peran == "penjahit")
            <div class="score pull-left">
                <div id="title">Ratting</div>
                <div id="body">8.5</div>
                <div id="bottom">100 proyek</div>
            </div>
            @endif
            <div class="user-data pull-left">
                <div class="title">
                    <h4>{{ $userDetail->nama_user }} <span>{{ $userDetail->alamat }}</span></h4> 
                    <p id="email">{{ $userDetail->email }}</p>
                    <p id="phone">{{ $userDetail->no_telp }}</p>
                </div>
            </div>
        </div>
        
        <div class="bottom">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#portofolio" aria-controls="portofolio" 
                        role="tab" data-toggle="tab">Portofolio
                    </a>
                </li>
                <li role="presentation">
                    <a href="#tentang" aria-controls="tentang" 
                        role="tab" data-toggle="tab">Tentang
                    </a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="portofolio">
                    <br>
                    <div class="row">
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="tentang">
                    <br>
                    <div class="row">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop