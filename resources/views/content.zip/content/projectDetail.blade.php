@extends('base')

@section('subtitle') Detail Proyek @stop

@section('content')
<div class="row">
    <div class="col-md-8">
        <h1>{{ $proyek[0]->nama_proyek }} </h1>
    </div>
</div>
<br>
<div class="content">
    <br>
    {{ $proyek[0]["nama_proyek"] }}
    @foreach($projectAttr as $attr)
        {{ $attr->kategori }}
    @endforeach

    <div>
        @if($viewMode == "pendingView")
        <a href="#" class="btn btn-info">Lihat Tawaran</a>
        @elseif($viewMode == "ongoingView")
        <a href="#" class="btn btn-success">Konfirmasi Pembayaran</a>
        @elseif($viewMode == "finishedView")
        <a href="#" class="btn btn-info">Buat Testimonial</a>
        <a href="#" class="btn btn-default">Minta Perbaikan</a>
        @endif
    </div>
</div>
@stop
