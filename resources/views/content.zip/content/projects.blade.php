@extends('base')

@section('subtitle') Semua poryek @stop

@section('content')
<div class="row">
    <div class="col-md-8">
        <h1>Daftar Proyek </h1>
    </div>
</div>
<br>
<div class="content">
    <br>
    <div class="row">
        @if($hasProject == 1)
        <div class="alert alert-danger">
            Anda tidak dapat melakukan penawaran selama masih dalam proyek berjalan!!
        </div>
        @endif
        @foreach($projects as $project)
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <img src="{{ asset('/images/img1.png') }}" alt="...">
                    <div class="caption">
                        <h3>{{ $project->nama_proyek }}</h3>
                        <p>{{ $project->nama_penjahit }}</p>
                        @if($hasProject == 0)
                        <p>
                            <a href="/WEB/project-detail/{{ $project->id_proyek }}" class="btn btn-info" role="button">Lihat Detail</a> 
                            <a href="/WEBs/makebid/{{ $project->id_proyek }}" 
                                class="btn btn-success" role="button">Tawar Proyek</a>
                        </p>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@stop
